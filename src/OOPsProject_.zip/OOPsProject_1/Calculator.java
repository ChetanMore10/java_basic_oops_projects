package OOPsProject_1;

public class Calculator {

	public int getAddition(int a, int b) {
		int sum = a + b;
		return sum;
	}

	public int getSubstraction(int a, int b) {
		int sum = a - b;
		return sum;
	}

	public int getMultiplication(int a, int b) {
		int sum = a * b;
		return sum;
	}

	public int getDivision(int a, int b) {
		int sum = a / b;
		return sum;
	}
}

